import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AppService } from "../../app.service";
import { Guest } from "../Entity/guest";
@Component({
  selector: 'demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})


export class DemoComponent implements OnInit {
  loginForm: FormGroup;
  isFailed = false;
  guest= new Guest();

  constructor(private appService: AppService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: new FormControl('', [Validators.required, Validators.email, Validators.maxLength(50)]),
      password: new FormControl('', [Validators.required, Validators.maxLength(50)])
    });
  }
  login() {
    this.appService.login(this.loginForm.value).subscribe(data => {
      this.guest=<Guest>JSON.parse(JSON.stringify(data));
      this.router.navigate(['/itinerary',this.guest.guestID]);
      this.isFailed = false;
    }, error => {
      this.isFailed = true;
    })

  }
}

