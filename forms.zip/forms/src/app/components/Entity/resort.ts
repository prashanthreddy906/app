export class Resort{
  rReservationNumber:string;
    guestId:string;
    roomType:string;
    arrivalDate:string;
    departureDate:string;
    noOfPeople: string;
    status:string;
    createdDate:string;
    updatedDate:string;
}