export class Dining{
    dReservationNumber:string;
    guestId:string;
    diningType:string;
    arrivalDate:string;
    noOfPeople: string;
    status:string;
    createdDate:string;
    updatedDate:string;
}