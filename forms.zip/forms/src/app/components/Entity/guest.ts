export class Guest{
     guestId: string;
     email :string;
     firstName : string;
     lastName :string;
     address : string;
     phone : number;
     password : string;
     createdDate : string;
     updatedDate : string;
}