import { Component, OnInit } from '@angular/core';
import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { Http, Response } from '@angular/http';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-book-resort',
  templateUrl: './book-resort.component.html',
  styleUrls: ['./book-resort.component.css']
})
export class BookResortComponent implements OnInit {

   constructor (
    private http: Http
  ) {}

  ngOnInit() {
  }


}
