import { Component, OnInit } from '@angular/core';
import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { Http, Response } from '@angular/http';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-book-dining',
  templateUrl: './book-dining.component.html',
  styleUrls: ['./book-dining.component.css']
})
export class BookDiningComponent implements OnInit {

  constructor(private http:Http) { }

  ngOnInit() {
  }

 book() {

  let data = JSON.stringify({ username: 'username', password: 'password' });

  this.http.post('http://localhost:3001/sessions/create', data, {
    })
    .subscribe(
      data => {
        console.log(data);
      }
     
    );
  }
}
