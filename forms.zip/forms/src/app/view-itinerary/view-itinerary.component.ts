import { Component, OnInit } from '@angular/core';
import { AppService } from "../app.service";
import { Guest } from "../components/Entity/guest";
import {Resort  } from "../components/Entity/resort";
import {Dining  } from "../components/Entity/dining";
@Component({
  selector: 'app-view-itinerary',
  templateUrl: './view-itinerary.component.html',
  styleUrls: ['./view-itinerary.component.css']
})
export class ViewItineraryComponent implements OnInit {
guestId:string;
  guest=new Guest();
  resortList: Resort[] = [];
  diningList: Dining[] = [];
    login=false;
  constructor(private appService: AppService ) {
   }

  ngOnInit() {
    this.getGuest();
  }
 
  getGuest(){
// this.appService.getGuest(this.guestId).subscribe(data=>{
  this.guest=<Guest>JSON.parse(window.localStorage.getItem("guest"));
// },error=>{
  console.log(JSON.stringify(this.guest));
    this.getViewData();
// });
  }
  getViewData(){
this.appService.getViewData(this.guest.guestId).subscribe(data=>{
this.resortList=[];
this.diningList=[];
this.resortList=<any[]>JSON.parse(JSON.stringify(data[0]));
this.diningList=<any[]>JSON.parse(JSON.stringify(data[1]));
},error=>{

});
  }
}
