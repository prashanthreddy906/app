import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { DemoComponent } from './components/demo/demo.component';
import { RegisterComponent } from './components/register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ItineraryComponent } from './itinerary/itinerary.component';
import { AppService } from './app.service';
import { HttpModule } from '@angular/http';

const appRoutes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component:DemoComponent  },
      { path: 'register', component:RegisterComponent  },
       { path: 'itinerary', component:ItineraryComponent  },
       { path: 'itinerary/:guestId', component:ItineraryComponent  },

];

@NgModule({
  declarations: [
    AppComponent,
    DemoComponent,
    RegisterComponent,
    ItineraryComponent
  ],
  imports: [
    HttpModule,
    RouterModule.forRoot(
      appRoutes),FormsModule,BrowserModule,ReactiveFormsModule
  ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
