import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-dining-confirmation',
  templateUrl: './book-dining-confirmation.component.html',
  styleUrls: ['./book-dining-confirmation.component.css']
})
export class BookDiningConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
