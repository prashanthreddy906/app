import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-resort-confirmation',
  templateUrl: './book-resort-confirmation.component.html',
  styleUrls: ['./book-resort-confirmation.component.css']
})
export class BookResortConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
