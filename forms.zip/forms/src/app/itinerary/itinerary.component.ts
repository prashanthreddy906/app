import { Component, OnInit } from '@angular/core';
import { AppService } from "../app.service";
import {ActivatedRoute} from '@angular/router';
import { Guest } from "../components/Entity/guest";
import {Resort  } from "../components/Entity/resort";
import {Dining  } from "../components/Entity/dining";
@Component({
  selector: 'itinerary',
  templateUrl: './itinerary.component.html',
  styleUrls: ['./itinerary.component.css']
})
export class ItineraryComponent implements OnInit {
guestId:string;
  isResort = false;
  isDining = false;
  isItinerary = true;
  guest=new Guest();
  resortList: Resort[] = [];
  diningList: Dining[] = [];
  constructor(private appService: AppService,private route: ActivatedRoute ) {
    this.guestId = route.snapshot.params['guestId'];
   }

  ngOnInit() {
    this.getGuest();
    this.getViewData();
  }
  bookResort() {
    this.isResort = true;
    this.isDining = false;
    this.isItinerary = false;
  }
  bookDining() {
    this.isResort = false;
    this.isDining = true;
    this.isItinerary = false;
  }
  viewItinerary() {
    this.isResort = false;
    this.isDining = false;
    this.isItinerary = true;
  }
  getGuest(){
this.appService.getGuest(this.guestId).subscribe(data=>{
  this.guest=<Guest>JSON.parse(JSON.stringify(data));
},error=>{

});
  }
  getViewData(){
this.appService.getViewData(this.guestId).subscribe(data=>{
this.resortList=[];
this.diningList=[];
this.resortList=<any[]>JSON.parse(JSON.stringify(data[0]));
this.diningList=<any[]>JSON.parse(JSON.stringify(data[1]));
},error=>{

});
  }

}
